package ru.gb.prev;

public class Main {
    public static void main(String[] args) {
        Employee[] employee = {
                new Employee("Maks", 55),
                new Employee("Denis", 44),
                new Employee("Mike", 15),
                new Employee("Berta", 67),
        };
        for (int i = 0; i < employee.length; i++) {
            if (employee[i].getAge() >= 40) {
                employee[i].printPersonalInfo();
            }


        }
    }
}
